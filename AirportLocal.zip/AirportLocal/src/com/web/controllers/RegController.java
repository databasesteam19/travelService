package com.web.controllers;

//import java.io.PrintWriter;
//import javax.servlet.http.HttpServlet; 
import com.web.connections.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/register")
public class RegController extends HttpServlet {

	/**
	 * Controls the Registration action from 'reg-form.html'
	 */
	private static final long serialVersionUID = 6899012923900934538L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		response.setContentType("text/html");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Connection conn = DBConnection.getConnection();
		try {
			Statement s = conn.createStatement();
			s.executeUpdate("insert into customer(customer_id,password)values('"+username+"','"+password+"')");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("sdfsDFasdfgSDF");
		//RequestDispatcher rd = request.getRequestDispatcher("/AirportLocal/html/login-form.html");
		//rd.forward(request,response);
	}
}
